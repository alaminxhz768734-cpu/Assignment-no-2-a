#include<stdio.h>
int main (){
float Km, meter;
scanf("%f", &Km);
meter= Km *1000;
printf (" Meter= %2f", meter);

return 0;
}
