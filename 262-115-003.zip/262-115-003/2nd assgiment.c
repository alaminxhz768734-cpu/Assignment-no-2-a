#include<stdio.h>
int main () {
printf(" Name: Abrar_ Alamin\n");
printf(" Father name:___________\n");
printf( " Mother name:___________\n");





return 0 ;
}
