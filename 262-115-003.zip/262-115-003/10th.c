#include<stdio.h>
int main () {
int days, years,months,remaining;
scanf("%d", &days);
years= days/365;
remaining= days %365;
months= remaining/30;
remaining= remaining% 30;
printf("years= %d\n",years);
printf(" months=%d\n", months);
printf(" days=%d",days);






return 0;
}
