#include<stdio.h>
int main (){
float c,f ;
scanf( "%f",&c);
f=(9*c)/5+32;
printf(" fahrenheit= %f",f);
return 0;
}
