#include<stdio.h>
int main () {
int n, tens, ones, reverse;
scanf ("%d", &n);
tens = n/ 10;
ones =n%10;
reverse= ones *10+ tens;
printf("reverse= %d",reverse);

return 0;
}
